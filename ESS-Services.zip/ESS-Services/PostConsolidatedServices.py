from Auth import *
from Config import *
import requests
import pandas
from typing import List
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
import Logs as log
import datetime


#SettingUpData
sheetName ='Application Health'
header ={'content-type':'application/json', 'x-api-key':apikey, 'authorization': 'Bearer '+GetToken()}
appPerformanceIds = []
compositeAppProviderIds = []
appIds=[]

def getColumnNames(header,columns):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=header,usecols=columns).columns
all_ids=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22']
appSQVID=[]


def Post_UOM_ASQV():    
    print('Startiing OUM-ASQV')
    rowData=[]
    columnNames=[] 
    AssessmentNo=[]
    AssessmentDate=[]

    for index, row in fetchExcelData(sheetName,4,'S:T').iterrows():
        if(index>0):
            AssessmentNo.append(row["Assesment Number"])
            date =row["Assesment Date"].strftime('%m/%d/%Y')
            AssessmentDate.append(date)
            

    for column in getColumnNames(5,'V:Z'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'V:Z').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Business',AssessmentNo[index],AssessmentDate[index])
        appSQVID.clear()
    #####--------------------------------------------
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'AA:AF'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'AA:AF').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Run And Operate',AssessmentNo[index],AssessmentDate[index])
        appSQVID.clear()
    ####---------------------------------------------
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'AG:AI'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'AG:AI').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Architecture and Engineering',AssessmentNo[index],AssessmentDate[index])
        appSQVID.clear()
    ####-----------------------------------------------
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'AJ:AQ'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'AJ:AQ').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('North Star',AssessmentNo[index],AssessmentDate[index])
        appSQVID.clear()




def PostAPM(columnName,Assessment,Date):
    print('APM Executing')
    temp =[]
    for id in appSQVID:
        temp.append({"id": id}) 
    result=json.loads(json.dumps(temp))
    body={ "instances": [{ "name": columnName, "Assessment Number": str(Assessment), "pm_measure_date_iso_8601": str(Date),"className": "Application_Performance_Measure", "pm_performance_value":  result  }]}
    response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
    appId=response.json()["instances"][0]["id"]
    appIds.append(appId)
    #print(appIds)
    #settingUpData(appId)
    #updateAssessments(appIds)
    # print('app executing')
    



appUniqueRefId=[]
appUniqueId=[]
Columns=['1','2','3','4']

def settingUpData():
    refIdCount=0
    getAllApplicationRequest=requests.get(baseUrl+getAllClassInstanceUrl,headers=header)
    for p_id in getAllApplicationRequest.json()['instances']:
            uniqueRefId = p_id.get('ea_reference')
            uniqueId=p_id.get('id')
            appUniqueRefId.append(uniqueRefId)
            appUniqueId.append(uniqueId)
    
    temp =[]
    for index, row in fetchExcelData(sheetName,4,'B:U').iterrows():
        result=None
        if (index>0):      
            for rowInd in range(len(appIds)):
                temp.append({"id": appIds[index-1]})
                temp.append({"id": appIds[index+3]})
                temp.append({"id": appIds[index+7]})
                temp.append({"id": appIds[index+11]})
                break
            result=json.loads( json.dumps(temp))   
            temp.clear()
            
            compositeAppBody={"instances":[
                            { "ea_reference":row["APP_CMDB_REF/Number"], 
                              "name": row["NAME"], 
                              "className": "Composite_Application_Provider",
                              "description": row["Short Description"],
                              "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
                              "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
                              "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
                              "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
                              "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
                              "lifecycle_status_application_provider": {"name": str(row["Status"]),"className": "Project_Lifecycle_Status","enumeration_value": str( row["Status"])  },
                              "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
                              "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
                              "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
                                        "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}},
                                        {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Vertical Owner"],"className": "Individual_Actor"},
                                        "act_to_role_to_role": {"name": row["Vertical Owner"],"className": "Individual_Business_Role"}}],
                                        "performance_measures_test": result
                            }]}
            print(len(appUniqueRefId))        
            if(len(appUniqueRefId)>0 and index<= len(appUniqueRefId) and appUniqueRefId[refIdCount]==row["APP_CMDB_REF/Number"]):
                compositeAppBody={"instances":[
                            { "id": str(appUniqueRefId[refIdCount]),"ea_reference":row["APP_CMDB_REF/Number"], 
                              "name": row["NAME"], 
                              "className": "Composite_Application_Provider",
                              "description": row["Short Description"],
                              "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
                              "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
                              "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
                              "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
                              "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
                              "lifecycle_status_application_provider": {"name": str(row["Status"]),"className": "Project_Lifecycle_Status","enumeration_value": str( row["Status"])  },
                              "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
                              "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
                              "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
                                        "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}},
                                        {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Vertical Owner"],"className": "Individual_Actor"},
                                        "act_to_role_to_role": {"name": row["Vertical Owner"],"className": "Individual_Business_Role"}}],
                                        "performance_measures_test": result
                            }]}
                updateComposteApplicationProvider(compositeAppBody)
                refIdCount+=1
            else:
                makeComposteApplicationProvider(compositeAppBody)
    print('Application Executed')
    updateRefrence()


def fetchExcelData(sheetName,headerValue,colsRange):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=headerValue,usecols=colsRange)


def makeComposteApplicationProvider(instanceBody):
    print('making apps')
    response=requests.post(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
    compostieAppId=response.json()["instances"][0]["id"]
    compositeAppProviderIds.append(compostieAppId)
    print(response.content)

def updateComposteApplicationProvider(instanceBody):
    print('updating apps')
    response=requests.patch(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
    compostieAppId=response.json()["instances"][0]["id"]
    compositeAppProviderIds.append(compostieAppId)
    print(response.content)


def updateRefrence():
    count = 0
    for appIndex in range(len(appIds)):
        count +=1
        for comIndex in range(len(compositeAppProviderIds)):    
            instancebody= { "id":appIds[appIndex],"className": "Application_Performance_Measure", "Application Measured": {"id": compositeAppProviderIds[count-1]}}
            response=requests.patch(baseUrl+updateInstanceUrl,json=instancebody,headers=header)
            if(count==len(compositeAppProviderIds)):
                count=0
            break    
    print('Refrence updated')



# def updateRefrence():
#     count = 0
#     for comIndex in range(len(compositeAppProviderIds)):
#         count +=1
#         getSequenceIdCount=0
#         for appIndex in range(len(appIds)):
#             if(getSequenceIdCount==0):    
#                 instancebody= { "id":appIds[appIndex],"className": "Application_Performance_Measure", "Application Measured": {"id": compositeAppProviderIds[count-1]}}
#             if(getSequenceIdCount==0):   
#                 instancebody= { "id":appIds[appIndex+4],"className": "Application_Performance_Measure", "Application Measured": {"id": compositeAppProviderIds[count-1]}} 
            
#             response=requests.patch(baseUrl+updateInstanceUrl,json=instancebody,headers=header)
#             if(count==len(compositeAppProviderIds)):
#                 count=0
#             break    
#     print('Refrence updated')






Post_UOM_ASQV()
settingUpData()




