from Auth import *
from Config import *
import requests
import pandas
from typing import List
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
import Logs as log


sheetName ='Application Health'
header ={'content-type':'application/json', 'x-api-key':apikey, 'authorization': 'Bearer '+GetToken()}
#appPerformanceIds = []
compositeAppProviderIds = []
appIds=[]
all_ids=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22']
appSQVID=[]
columnName=['Business','Run&Operate','AE','NorthStar']

# def createAppService():
#     print('creting service')
#     for value in getColumnNames(5,'V:Z'):
#         for index, row in fetchExcelData(sheetName,5,'V:Z').iterrows():
#             appPerformanceMeasureBody= {"name": value,"className": "Application_Performance_Measure", 
#                             "pm_performance_value": [{
#                             "name": value,"className": "Application_Service_Quality_Value",
#                             "service_quality_value_uom": {"name": value,"className": "Unit_Of_Measure","enumeration_value": value},
#                             "service_quality_value_value":str(row[value])
#                             }]}
#             print(appPerformanceMeasureBody)
#             response=requests.post(baseUrl+createInstanceUrl,json=appPerformanceMeasureBody,headers=header)
#             appPerformanceId=response.json()["id"]
#             appPerformanceIds.append(appPerformanceId)
#     print('serivce created')
#     updateAssessments(appPerformanceIds)
#     settingUpData(appPerformanceIds)

def getColumnNames(header,columns):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=header,usecols=columns).columns


# def Post_UOM_ASQV():    
#     print('Startiing OUM-ASQV')
#     rowData=[]
#     columnNames=[]  
#     for column in getColumnNames(5,'V:AQ'):
#         columnNames.append(column)

#     for index, row in fetchExcelData(sheetName,5,'V:AQ').iterrows():
#         for column in columnNames:
#             rowData.append({"name": column, "className": "Application_Service_Quality_Value",
#                         "service_quality_value_value":str(row[column]),
#                         "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
#         result=json.loads(json.dumps(rowData))
#         body={"instances":result}
#         response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
#         rowData.clear()    
#         for p_id in response.json()['instances']:
#             hay = p_id.get('id')
#             appSQVID.append(hay)
#         #PostAPM(index)
#         appSQVID.clear()



# def PostAPM(colums):
#     print('APM Executing')
#     temp =[]
#     for id in appSQVID:
#         temp.append({"id": id})
#     result=json.loads(json.dumps(temp))
#     body={ "instances": [{ "name": columnName[colums],  "className": "Application_Performance_Measure", "pm_performance_value":  result  }]}
#     response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
#     appId=response.json()["instances"][0]["id"]
#     appIds.append(appId)
#     settingUpData(appId)
#     #updateAssessments(appIds)
#     # print('app executing')



# def settingUpData(appPerformanceIds):
#     temp =[]
#     for id in appPerformanceIds:
#         temp.append({"id": id})
#     result=json.loads( json.dumps(temp))

#     for index, row in fetchExcelData(sheetName,4,'B:O').iterrows():
#         if (index>0):
#             compositeAppBody={"instances":[{ "ea_reference":row["APP_CMDB_REF/Number"], "name": row["NAME"], "className": "Composite_Application_Provider",
#                         "description": row["Short Description"],
#                         "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
#                         "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
#                         "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
#                         "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
#                         "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
#                         "lifecycle_status_application_provider": {"name": row["Status"],"className": "Project_Lifecycle_Status","enumeration_value": row["Status"]  },
#                         "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
#                         "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
#                         "stakeholders": [{"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": { "name": row["Domain Architect"],"className": "Individual_Actor"}},
#                                         {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor":  { "name": row["Vertical Owner"],"className": "Individual_Actor"}}],
#                                         "performance_measures_test": result
#                         }]}
#                         # 
#             makeComposteApplicationProvider(compositeAppBody)
#     print('Application Executed')
#     updateRefrence()


# def fetchExcelData(sheetName,headerValue,colsRange):
#     return pandas.read_excel(filePath,sheet_name=sheetName, header=headerValue,usecols=colsRange)


# def makeComposteApplicationProvider(instanceBody):
#     response=requests.post(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
#     compostieAppId=response.json()["instances"][0]["id"]
#     compositeAppProviderIds.append(compostieAppId)
  
    


# def updateRefrence():
#     count = 0
#     for appIndex in range(len(appIds)):
#         count +=1
#         for comIndex in range(len(compositeAppProviderIds)):    
#             instancebody= { "id":appIds[appIndex],"className": "Application_Performance_Measure", "Application Measured": {"id": compositeAppProviderIds[count-1]}}
#             response=requests.patch(baseUrl+updateInstanceUrl,json=instancebody,headers=header)
#             if(count==len(compositeAppProviderIds)):
#                 count=0
#             break    
#     print('Refrence updated')
    
    
    
    
#     Post_UOM_ASQV()



#     def PostSQVUOMBusiness():
#     print('SQV-Business')
#     for value in getColumnNames(5,'V:Z'):
#         for index, row in fetchExcelData(sheetName,5,'V:Z').iterrows():
#             body={ "name": value,"className": "Application_Service_Quality_Value","service_quality_value_value":str(row[value]),
#                    "service_quality_value_uom": { "name": value,"className": "Unit_Of_Measure", "enumeration_value": value}}
#             response=requests.post(baseUrl+createInstanceUrl,json=body,headers=header)
#             appPerformanceId=response.json()["id"]
#             appPerformanceIds.append(appPerformanceId)       
#     print('SQV-Business-Executed')
    


# def PostSQVUOMRunOperate(rowval):
#     print('SQV-RO')
#     print(rowval)
#     for value in getColumnNames(5,'AA:AF'):
#         for index, row in fetchExcelData(sheetName,5,'AA:AF').iterrows():
#             body={ "name": value,"className": "Application_Service_Quality_Value","service_quality_value_value":str(row[value]),
#                     "service_quality_value_uom": { "name": value,"className": "Unit_Of_Measure", "enumeration_value": value}}
#             response=requests.post(baseUrl+createInstanceUrl,json=body,headers=header)
#             appPerformanceId=response.json()["id"]
#             appPerformanceIds.append(appPerformanceId)          
#     print('SQV-RO-Executed')   
    
    
# def PostAE():
#     print('SQV-AE')
#     for value in getColumnNames(5,'AG:AI'):
#         for index, row in fetchExcelData(sheetName,5,'AG:AI').iterrows():
#             body={ "name": value,"className": "Application_Service_Quality_Value","service_quality_value_value":str(row[value]),
#                     "service_quality_value_uom": { "name": value,"className": "Unit_Of_Measure", "enumeration_value": value}}
#             response=requests.post(baseUrl+createInstanceUrl,json=body,headers=header)
#             appPerformanceId=response.json()["id"]
#             appPerformanceIds.append(appPerformanceId)
#     print('SQV-AE-Executed')



# def updateAssessments(ids):
#     print('Assesment updating')
#     for index, row in fetchExcelData(sheetName, 4,'S:T').iterrows():
#         if(index>0):
#             body= { "id": ids[index-1], "className": "Application_Performance_Measure", "Assessment Number": str(row[1]) }
#             # print(body)
#             # response = requests.patch(baseUrl+updateInstanceUrl,body,headers=header)
#             # print(response.content)
#             # print(response.status_code)
#     print('Assessment updated')
